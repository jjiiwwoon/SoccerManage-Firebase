/**
 * ====================================
 * 파일: firebase.js
 * 위치: frontend/src/firebase.js
 * 기능: Firebase 초기화 + Analytics 설정
 * ====================================
 */
import { initializeApp } from 'firebase/app';
import { getAnalytics } from 'firebase/analytics';

// Firebase 콘솔 > 프로젝트 설정 > 일반 > 내 앱 에서 확인 가능
const firebaseConfig = {
    apiKey: "여기에_API_KEY_입력",
    authDomain: "changwoofc.firebaseapp.com",
    projectId: "changwoofc",
    storageBucket: "changwoofc.firebasestorage.app",
    messagingSenderId: "여기에_SENDER_ID_입력",
    appId: "여기에_APP_ID_입력",
    measurementId: "여기에_MEASUREMENT_ID_입력"
};

// Firebase 초기화
const app = initializeApp(firebaseConfig);

// Analytics 초기화 (브라우저 환경에서만)
let analytics = null;
if (typeof window !== 'undefined') {
    analytics = getAnalytics(app);
}

export { app, analytics };
